using CollegeManagement.Data;
using CollegeManagement.Models;
using Microsoft.AspNetCore.Mvc;

namespace CollegeManagement.Controllers;

public class TeacherController : Controller
{
    private readonly CollegeDbContext _context;

    public TeacherController(CollegeDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        var teachers = _context.Teachers.ToList();
        return View(teachers);
    }
}
