using CollegeManagement.Data;
using CollegeManagement.Models;
using Microsoft.AspNetCore.Mvc;

namespace CollegeManagement.Controllers;

public class AttendanceController : Controller
{
    private readonly CollegeDbContext _context;

    public AttendanceController(CollegeDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        var attendance = _context.AttendanceRecords.OrderBy(r => r.Date).ToList();
        return View(attendance);
    }
}
