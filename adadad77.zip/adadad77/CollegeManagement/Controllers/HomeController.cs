using System.Diagnostics;
using CollegeManagement.Data;
using CollegeManagement.Models;
using CollegeManagement.Services;
using Microsoft.AspNetCore.Mvc;

namespace CollegeManagement.Controllers;

public class HomeController : Controller
{
    private readonly CollegeDbContext _context;
    private readonly ReportManager _reportManager;

    public HomeController(CollegeDbContext context, ReportManager reportManager)
    {
        _context = context;
        _reportManager = reportManager;
    }

    public IActionResult Index()
    {
        var model = new
        {
            StudentCount = _context.Students.Count(),
            TeacherCount = _context.Teachers.Count(),
            GroupCount = _context.Groups.Count(),
            ReportSummary = _reportManager.GenerateSummary(_context.Students)
        };

        return View(model);
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
