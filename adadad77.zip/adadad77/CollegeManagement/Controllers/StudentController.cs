using CollegeManagement.Data;
using CollegeManagement.Models;
using Microsoft.AspNetCore.Mvc;

namespace CollegeManagement.Controllers;

public class StudentController : Controller
{
    private readonly CollegeDbContext _context;

    public StudentController(CollegeDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        var students = _context.Students.ToList();
        return View(students);
    }

    [HttpPost]
    public IActionResult Add(string name, string surname, int age, string groupName)
    {
        var student = new Student(name, surname, age, groupName);
        _context.Students.Add(student);
        _context.SaveChanges();
        return RedirectToAction(nameof(Index));
    }
}
