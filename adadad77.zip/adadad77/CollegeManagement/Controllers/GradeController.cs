using CollegeManagement.Data;
using CollegeManagement.Models;
using Microsoft.AspNetCore.Mvc;

namespace CollegeManagement.Controllers;

public class GradeController : Controller
{
    private readonly CollegeDbContext _context;

    public GradeController(CollegeDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        var grades = _context.Grades.ToList();
        return View(grades);
    }
}
