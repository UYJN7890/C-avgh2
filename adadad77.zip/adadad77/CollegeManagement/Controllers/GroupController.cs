using CollegeManagement.Data;
using CollegeManagement.Models;
using Microsoft.AspNetCore.Mvc;

namespace CollegeManagement.Controllers;

public class GroupController : Controller
{
    private readonly CollegeDbContext _context;

    public GroupController(CollegeDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        var groups = _context.Groups.ToList();

        foreach (var group in groups)
        {
            group.Students = _context.Students
                .Where(s => s.GroupName == group.Name)
                .ToList();
        }

        return View(groups);
    }
}
