namespace CollegeManagement.Models;

public class UserAccount : User
{
    public UserAccount()
    {
    }

    public int Id { get; set; }
    public string Login { get; private set; } = string.Empty;
    public bool IsLoggedIn { get; private set; }

    public UserAccount(string login, string password)
        : base(login, password)
    {
        Login = login;
    }

    public bool SignIn(string login, string password)
    {
        if (login == Login && password == Password)
        {
            IsLoggedIn = true;
            return true;
        }

        return false;
    }

    public void Logout()
    {
        IsLoggedIn = false;
    }
}
