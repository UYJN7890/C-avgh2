namespace CollegeManagement.Models;

public class AttendanceRecord
{
    public int Id { get; set; }
    public int StudentId { get; set; }
    public DateOnly Date { get; set; }
    public bool IsPresent { get; set; }
}
