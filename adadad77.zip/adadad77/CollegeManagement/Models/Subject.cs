namespace CollegeManagement.Models;

public class Subject
{
    public int Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public int Hours { get; set; }
    private Teacher? teacher;

    public Teacher? Teacher => teacher;

    public void AssignTeacher(Teacher teacherToAssign)
    {
        if (teacherToAssign is null)
        {
            throw new ArgumentNullException(nameof(teacherToAssign));
        }

        teacher = teacherToAssign;
    }
}
