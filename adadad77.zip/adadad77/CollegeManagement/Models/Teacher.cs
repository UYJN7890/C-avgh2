namespace CollegeManagement.Models;

public class Teacher : Person
{
    private int experience;

    public Teacher()
        : base(string.Empty, string.Empty, 0)
    {
    }

    public int Id { get; set; }
    public string Subject { get; private set; } = string.Empty;

    public int Experience
    {
        get => experience;
        private set => experience = value;
    }

    public Teacher(string name, string surname, int age, string subject)
        : base(name, surname, age)
    {
        Subject = subject;
    }

    public Teacher(string name, string surname, int age, string subject, int experience)
        : this(name, surname, age, subject)
    {
        Experience = experience;
    }

    public void UpdateExperience(int newExperience)
    {
        if (newExperience < 0)
        {
            throw new ArgumentOutOfRangeException(nameof(newExperience), "Стаж не может быть отрицательным.");
        }

        Experience = newExperience;
    }

    public string GetTeacherInfo()
    {
        return $"{GetFullName()}, предмет: {Subject}, стаж: {Experience} лет.";
    }
}
