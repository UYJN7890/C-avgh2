namespace CollegeManagement.Models;

public class Group
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public int Course { get; set; }
    public ICollection<Student> Students { get; set; } = new List<Student>();

    public bool AddStudent(Student student)
    {
        if (student is null)
        {
            return false;
        }

        if (Students.Any(s => s.StudentId == student.StudentId))
        {
            return false;
        }

        Students.Add(student);
        student.AssignGroup(Name);
        return true;
    }

    public bool RemoveStudent(int studentId)
    {
        var student = Students.FirstOrDefault(s => s.StudentId == studentId);
        if (student is null)
        {
            return false;
        }

        Students.Remove(student);
        return true;
    }

    public string GetSummary()
    {
        return $"{Name} ({Course} курс), студентов: {Students.Count}";
    }
}
