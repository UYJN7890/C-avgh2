namespace CollegeManagement.Models;

public class Grade
{
    public int Id { get; set; }
    public int StudentId { get; set; }
    public int Value { get; set; }
    public string Subject { get; set; } = string.Empty;

    public bool IsValid() => Value >= 2 && Value <= 5;
}
