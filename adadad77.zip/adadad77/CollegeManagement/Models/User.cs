namespace CollegeManagement.Models;

public class User
{
    public string UserName { get; protected set; } = string.Empty;
    public string Password { get; protected set; } = string.Empty;

    public User()
    {
    }

    public User(string userName, string password)
    {
        UserName = userName;
        Password = password;
    }

    protected internal string GetDisplayName() => UserName;
}
