namespace CollegeManagement.Models;

public class Student : Person
{
    private readonly List<int> _grades = new();

    public Student()
        : base(string.Empty, string.Empty, 0)
    {
    }

    public int StudentId { get; private set; }
    public string GroupName { get; private set; } = string.Empty;
    public IReadOnlyCollection<int> Grades => _grades.AsReadOnly();

    public Student(string name, string surname, int age, string groupName)
        : base(name, surname, age)
    {
        ValidateStudentData();
        StudentId = Math.Abs(Guid.NewGuid().GetHashCode());
        GroupName = groupName;
    }

    public string FullName => GetFullName();
    public int AgeValue => Age;

    public void SetAge(int age)
    {
        if (age < 15 || age > 70)
        {
            throw new ArgumentOutOfRangeException(nameof(age), "Возраст студента должен быть от 15 до 70 лет.");
        }

        Age = age;
    }

    public string GetStudentInfo()
    {
        return $"{GetFullName()}, {Age} лет, группа {GroupName}";
    }

    public bool AddGrade(int grade)
    {
        if (grade < 2 || grade > 5)
        {
            return false;
        }

        _grades.Add(grade);
        return true;
    }

    public void AssignGroup(string groupName)
    {
        GroupName = groupName;
    }

    private void ValidateStudentData()
    {
        if (string.IsNullOrWhiteSpace(Name) || string.IsNullOrWhiteSpace(Surname))
        {
            throw new InvalidOperationException("Имя и фамилия студента обязательны.");
        }

        if (Age < 15 || Age > 70)
        {
            throw new InvalidOperationException("Возраст студента должен находиться в диапазоне от 15 до 70 лет.");
        }
    }
}
