namespace CollegeManagement.Models;

public abstract class Person
{
    public string Name { get; protected set; } = string.Empty;
    public string Surname { get; protected set; } = string.Empty;
    public int Age { get; protected set; }

    protected Person(string name, string surname, int age)
    {
        Name = name;
        Surname = surname;
        Age = age;
    }

    protected void DisplayBasicInfo()
    {
        Console.WriteLine($"{Name} {Surname}, age {Age}");
    }

    protected internal string GetFullName()
    {
        return $"{Name} {Surname}";
    }
}
