using CollegeManagement.Data;
using CollegeManagement.Models;
using CollegeManagement.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<CollegeDbContext>(options =>
    options.UseSqlite("Data Source=college.db"));
builder.Services.AddScoped<StudentService>();
builder.Services.AddScoped<ReportManager>();
builder.Services.AddScoped<AttendanceManager>();

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<CollegeDbContext>();
    db.Database.EnsureCreated();

    if (!db.Students.Any())
    {
        var students = new[]
        {
            new Student("Иван", "Иванов", 19, "КС-101"),
            new Student("Мария", "Петрова", 20, "КС-101"),
            new Student("Алексей", "Смирнов", 18, "КС-202")
        };

        db.Students.AddRange(students);
        db.SaveChanges();
    }

    if (!db.Teachers.Any())
    {
        db.Teachers.AddRange(
            new Teacher("Ольга", "Кузнецова", 35, "Математика", 12),
            new Teacher("Павел", "Николаев", 41, "Программирование", 18));
        db.SaveChanges();
    }

    if (!db.Groups.Any())
    {
        var students = db.Students.ToList();
        db.Groups.AddRange(
            new Group { Name = "КС-101", Course = 1, Students = students.Where(s => s.GroupName == "КС-101").ToList() },
            new Group { Name = "КС-202", Course = 2, Students = students.Where(s => s.GroupName == "КС-202").ToList() });
        db.SaveChanges();
    }

    if (!db.Grades.Any())
    {
        var students = db.Students.ToList();
        db.Grades.AddRange(
            new Grade { StudentId = students[0].StudentId, Subject = "Математика", Value = 5 },
            new Grade { StudentId = students[0].StudentId, Subject = "Программирование", Value = 4 },
            new Grade { StudentId = students[1].StudentId, Subject = "Математика", Value = 4 },
            new Grade { StudentId = students[2].StudentId, Subject = "Программирование", Value = 5 });
        db.SaveChanges();
    }

    if (!db.AttendanceRecords.Any())
    {
        var students = db.Students.ToList();
        db.AttendanceRecords.AddRange(
            new AttendanceRecord { StudentId = students[0].StudentId, Date = DateOnly.FromDateTime(DateTime.Today.AddDays(-2)), IsPresent = true },
            new AttendanceRecord { StudentId = students[0].StudentId, Date = DateOnly.FromDateTime(DateTime.Today.AddDays(-1)), IsPresent = false },
            new AttendanceRecord { StudentId = students[1].StudentId, Date = DateOnly.FromDateTime(DateTime.Today.AddDays(-2)), IsPresent = true },
            new AttendanceRecord { StudentId = students[1].StudentId, Date = DateOnly.FromDateTime(DateTime.Today.AddDays(-1)), IsPresent = true });
        db.SaveChanges();
    }

    foreach (var teacher in db.Teachers.Where(t => t.Experience == 0).ToList())
    {
        teacher.UpdateExperience(teacher.Subject == "Математика" ? 12 : 18);
    }

    db.SaveChanges();
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseRouting();
app.UseAuthorization();

app.MapStaticAssets();
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}")
    .WithStaticAssets();

app.Run();
