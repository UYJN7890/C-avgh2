using CollegeManagement.Data;
using CollegeManagement.Models;

namespace CollegeManagement.Services;

public class StudentService
{
    private readonly CollegeDbContext _context;

    public StudentService(CollegeDbContext context)
    {
        _context = context;
    }

    public List<Student> GetAllStudents()
    {
        return _context.Students.OrderBy(s => s.FullName).ToList();
    }

    public void AddStudent(Student student)
    {
        if (student is null)
        {
            throw new ArgumentNullException(nameof(student));
        }

        _context.Students.Add(student);
        _context.SaveChanges();
    }
}
