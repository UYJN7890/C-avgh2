using CollegeManagement.Data;
using CollegeManagement.Models;

namespace CollegeManagement.Services;

public class AttendanceManager
{
    private readonly CollegeDbContext _context;

    public AttendanceManager(CollegeDbContext context)
    {
        _context = context;
    }

    public double CalculateAttendanceRate(int studentId)
    {
        var records = _context.AttendanceRecords.Where(r => r.StudentId == studentId).ToList();
        if (records.Count == 0)
        {
            return 0;
        }

        return records.Count(r => r.IsPresent) * 100.0 / records.Count;
    }
}
