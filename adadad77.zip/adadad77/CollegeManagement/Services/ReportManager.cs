using CollegeManagement.Models;

namespace CollegeManagement.Services;

public class ReportManager
{
    public string GenerateSummary(IEnumerable<Student> students)
    {
        var allStudents = students.ToList();
        var averageAge = allStudents.Count > 0 ? allStudents.Average(s => s.AgeValue) : 0;

        return $"Всего студентов: {allStudents.Count}. Средний возраст: {averageAge:F1}";
    }
}
